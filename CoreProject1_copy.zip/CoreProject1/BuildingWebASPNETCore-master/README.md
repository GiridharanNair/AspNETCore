## Resources for the "Building a Web App with ASP.NET Core RC1, MVC 6, EF7 & AngularJS" Course
### For my Pluralsight Course

To visit the course, see:

- My ASP.NET Core Course on Pluralsight: (http://shawnw.me/learnaspnetcore)
