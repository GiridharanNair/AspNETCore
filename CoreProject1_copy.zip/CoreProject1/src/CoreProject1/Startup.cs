﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using CoreProject1.Services;
using CoreProject1.Models;
using AutoMapper;
using CoreProject1.ViewModels;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authentication.Cookies;

namespace CoreProject1
{
    public class Startup
    {
        IHostingEnvironment _env;
        public Startup(IHostingEnvironment env)
        {
            _env = env;
            var builder = new ConfigurationBuilder()
                .SetBasePath(env.ContentRootPath)
                .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true)
                .AddJsonFile("config.json")
                .AddJsonFile($"appsettings.{env.EnvironmentName}.json", optional: true)
                .AddEnvironmentVariables();
            Configuration = builder.Build();
        }

        public IConfigurationRoot Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            // Add framework services.
            services.AddSingleton(Configuration);
            if (_env.IsDevelopment())
                services.AddScoped<IMailService, MailService>();
            services.AddIdentity<TripUser, IdentityRole>(role=>
                {
                    role.User.RequireUniqueEmail = true;
                    role.Password.RequiredLength = 8;
                    role.Cookies.ApplicationCookie.LoginPath = "/Auth/Login";
                    role.Cookies.ApplicationCookie.Events = new CookieAuthenticationEvents()
                    {
                        
                        OnRedirectToLogin=async ctx =>
                        {
                            if(ctx.Request.Path.StartsWithSegments("/api")&& 
                            ctx.Response.StatusCode==200){
                                ctx.Response.StatusCode = 401;
                            }
                            else
                            {
                                ctx.Response.Redirect(ctx.RedirectUri);
                            }
                            await Task.Yield();
                        }
                    };               
                }
                ).AddEntityFrameworkStores<WorldContext>();
            services.AddDbContext<WorldContext>();
            services.AddTransient<GeoCordsService>();
            services.AddScoped<IWorldRepository, WorldRepository>();
            services.AddTransient<WorldContextSeedData>();

            services.AddLogging();
            services.AddMvc(config=>
            {
                if(_env.IsProduction())
                config.Filters.Add(new RequireHttpsAttribute());
                else if(_env.IsDevelopment())
                config.Filters.Add(new RequireHttpsAttribute());
            }
            );
            //services.AddMvcCore();
            
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env,
            WorldContextSeedData seeder,
            ILoggerFactory loggerFactory,
            IConfigurationRoot _config)
        {
            loggerFactory.AddConsole(Configuration.GetSection("Logging"));
            

            //if (env.IsDevelopment())
            //{
            //    app.UseDeveloperExceptionPage();
            //    app.UseBrowserLink();
            //}
            //else
            //{
            //    app.UseExceptionHandler("/Home/Error");
            //}

            
            

            if (env.IsDevelopment()) {
                app.UseDeveloperExceptionPage();
                loggerFactory.AddDebug(LogLevel.Information);
            }
            else
            {
                loggerFactory.AddDebug(LogLevel.Error);
            }
            app.UseStaticFiles();
            app.UseIdentity();
            Mapper.Initialize(mapper =>
            {
                mapper.CreateMap<TripViewModel, Trip>().ReverseMap();
                mapper.CreateMap<StopViewModel, Stop>().ReverseMap();
            });
            app.UseMvc(x => x.MapRoute(name: "Default",
                template: "{controller}/{action}/{id?}",
                defaults: new { controller = "App", action = "Index" })
                );
            seeder.PlaceSeedData().Wait();

            app.UseFacebookAuthentication(new FacebookOptions()
            {
                AppId = _config["FaceBook:AppId"],
                AppSecret=_config["FaceBook:AppSecret"]
            });

            //app.UseMvc(routes =>
            //{
            //    routes.MapRoute(
            //        name: "default",
            //        template: "{controller=Home}/{action=Index}/{id?}");
            //});
        }
    }
}
