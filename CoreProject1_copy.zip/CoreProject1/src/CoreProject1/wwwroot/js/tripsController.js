﻿(function () {
    "use strict";
    //getting the existing module and adding a controller for the module
    angular.module("appTrips")
    .controller("tripsController", tripsController);
    function tripsController($http) {
        var vm = this;
        vm.trips = [];
        vm.newTrip = {};
        vm.errorMessage = "";
        vm.IsBusy = true;

        $http.get("/api/trips")
        .then(function (response) {
            //Success
            angular.copy(response.data, vm.trips);
        }, function (error) {
            //Failure
            vm.errorMessage = "Failed to load data" + error;
        })
        .finally(function () {
            vm.IsBusy = false;
        });


        //Delete Method for removing a Trip
        vm.DeleteTrip = function (tripName) {
            vm.IsBusy = true;
            vm.errorMessage = "";
            var url = "/api/trips/" + tripName.name;
            $http.delete(url)
            .then(function (response) {
                angular.copy(response.data, vm.trips);               
                vm.errorMessage = "Deleted successfully";
            }, function (error) {
                vm.errorMessage = "Error while deleting the data";
                console.log(error);
            })
            .finally(function () {
                vm.IsBusy = false;
            });
        };

        //Post Method
        vm.addTrip = function () {
            vm.IsBusy = true;
            vm.errorMessage = "";
            $http.post("/api/trips", vm.newTrip).
            then(function (response) {
                vm.trips.push(response.data);
            }, function (error) {
                vm.errorMessage = "Failed to save new trip";
            })
            .finally(function () {
                vm.IsBusy = false;
            })
        };
    }


    
}
)();