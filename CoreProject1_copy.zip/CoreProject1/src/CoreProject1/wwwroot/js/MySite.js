﻿//Mysite.js

(function () {
    var element = $("#userID");
    element.text("Giridharan Nair");

    var main = $("main");
    main.on("mouseenter", function () {
        main.style.backgroundColor = "#e66464";
    });

    main.on("mouseleave",function () {
        main.style.backgroundColor = "";
    });

    
    var $sidebarWrapper = $("#wrapper,#sidebar");
    var $icon = $("#sideToggleButton i.glyphicon")
    $("#sideToggleButton").on("click", function () {
        $sidebarWrapper.toggleClass("hide-sidebar");
        if ($sidebarWrapper.hasClass("hide-sidebar")) {
            $icon.removeClass("glyphicon-chevron-left");
            $icon.addClass("glyphicon-chevron-right");
        }
        else {
            $icon.removeClass("glyphicon-chevron-right");
            $icon.addClass("glyphicon-chevron-left");
        }
    });
    
})();