﻿(function () {
    "use strict";
    angular.module("appTrips")
    .controller("tripEditorController", tripEditorController);

    function tripEditorController($routeParams,$http) {
        var vm = this;
        vm.tripName = $routeParams.tripName;
        vm.Stops = [];
        vm.errorMessage = "";
        vm.IsTableVisible = false;
        vm.IsBusy = true;
        vm.newStop = {};
        $http.get("/api/trips/" + vm.tripName + "/stops")//`/api/trips/${vm.tripName}/stops`
        .then(function (response) {
           // alert('Received response');
            angular.copy(response.data, vm.Stops);
            vm.IsTableVisible = true;
            _showMap(vm.Stops);
        }, function (error) {
            vm.errorMessage = "Failed to get stops ";
        })
            .finally(function () {
                vm.IsBusy = false;
            });

        vm.addStop = function () {
            
            vm.IsBusy = true;
            $http.post("/api/trips/" + vm.tripName + "/stops", vm.newStop).
            then(function (response) {
                //alert('Success');
                vm.Stops.push(response.data);
                vm.IsTableVisible = true;
                _showMap(vm.Stops);
                vm.newStop = {};

            }, function (error) {
                vm.errorMessage = "Failed to add stop data";
            })
            .finally(function(){
                vm.IsBusy = false;
            });

        };


        vm.DeleteStops = function (stops) {
            vm.IsBusy = true;
            //alert(stops.name);
            $http.delete("/api/trips/" + vm.tripName+"|"+stops.name + "/stops", vm.newStop).
            then(function (response) {
                angular.copy(response.data, vm.Stops);
                _showMap(vm.Stops);
                vm.errorMessage = "Deleted successfully";
            }, function (error) {
                vm.errorMessage = "Failed to delete stop data";
            })
            .finally(function () {
                vm.IsBusy = false;
            });

        };


    };

    function _showMap(stops) {
        if (stops && stops.length > 0) {
            
            var mapStops = _.map(stops, function (item) {
               // alert(item.name);
                return {
                    
                    lat: item.latitude,
                    long: item.longitude,
                    info: item.name

                };
            });


            
            //Show Map
            travelMap.createMap({
                stops: mapStops,
                selector: "#map",
                currentStop: 1,
                initialZoom: 3
            });

        }

    }
})();