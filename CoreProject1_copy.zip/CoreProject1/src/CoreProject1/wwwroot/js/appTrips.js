﻿(function () {
    "use strict";
    //creating the module
    angular.module("appTrips", ["simpleControls", "ngRoute"])
    .config(function ($routeProvider) {

        $routeProvider.when("/",
            {
                controller: "tripsController",
                controllerAs: "vm",
                templateUrl:"/views/tripsView.html"
            });

        $routeProvider.when("/editor/:tripName", {
            controller: "tripEditorController",
            controllerAs: "vm",
            templateUrl:"/views/tripEditView.html"

        });

        $routeProvider.when("App/App/Trips/:trip.name",
            {
                controller: "tripsController",
                controllerAs: "vm",
                templateUrl: "/views/tripsView.html"
            });

        $routeProvider.otherwise({ redirectTo:"/" });

    });

})();