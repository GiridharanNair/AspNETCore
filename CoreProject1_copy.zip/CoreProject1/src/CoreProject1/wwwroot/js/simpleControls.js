﻿/// <reference path="../views/waitcursor.html" />
(function () {
    "use strict";
    angular.module("simpleControls", [])
        .directive("waitCursor", waitCursor);

    function waitCursor() {
        //alert('ads');
        return {
            restrict: "E",
            templateUrl: "/views/waitcursor.html"
        };
    };
})();