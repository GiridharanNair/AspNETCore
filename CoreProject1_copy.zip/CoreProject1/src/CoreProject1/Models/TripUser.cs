﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using System;

namespace CoreProject1.Models
{
    public class TripUser:IdentityUser
    {
        public DateTime FirstTrip { get; set; }
    }
}