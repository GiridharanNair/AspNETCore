﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoreProject1.Models
{
    public class WorldRepository:IWorldRepository
    {
        private WorldContext _context;
        private ILogger<WorldRepository> _logger;

        public WorldRepository(WorldContext context, ILogger<WorldRepository> logger)
        {
            _context = context;
            _logger = logger;
        }

        public IEnumerable<Trip> GetAllTrips()
        {
            _logger.LogInformation($"Started Collecting trip Data at {DateTime.UtcNow}");
            return _context.Trips.ToList();
        }

        public void AddTrip(Trip trip)
        {
            try { 
                _context.Add(trip);
                }
            catch(Exception ex)
                {
                _logger.LogError($"Something went wrong at {DateTime.UtcNow} Exception: {ex}");
                }
        }

        public async Task<bool> SaveChangesAsync()
        {
            return (await _context.SaveChangesAsync()) > 0;
        }

        public Trip GetTripByName(string tripName)
        {
            return _context.Trips
                .Include(x=>x.Stops)
                .Where(x => x.Name.Equals(tripName)).FirstOrDefault();
                
        }

        public void AddStop(string tripName, Stop newStop)
        {
            var trip = GetTripByName(tripName);
            if (trip != null)
            {
                trip.Stops.Add(newStop);
                _context.Stops.Add(newStop);
            }
        }

        public IEnumerable<Trip> GetAllTripsByUserName(string name)
        {
            _logger.LogInformation($"Started Collecting trip Data at {DateTime.UtcNow}");
            return _context
                .Trips
                .Include(x=>x.Stops)
                .Where(x => x.UserName.Equals(name)).ToList();
                            
        }

        public Trip GetUserTripByName(string tripName, string name)
        {
            return _context.Trips
                .Include(x => x.Stops)
                .Where(x => x.Name.Equals(tripName)
                && x.UserName.Equals(name)
                ).FirstOrDefault();
        }

        public void AddStop(string tripName, Stop newStop, string name)
        {
            var trip = GetUserTripByName(tripName,name);
            if (trip != null)
            {
                trip.Stops.Add(newStop);
                _context.Stops.Add(newStop);
            }
        }

        //public bool DeleteTrip(Trip newTrip)
        //{
        //    var tripID = GetTripIDByTripName(newTrip);
        //    newTrip.TripID = tripID;
        //    int status = DeleteStopForTripID(newTrip);
        //    return status > 0;

        //}

        private int DeleteStopForTripID(int tripID)
        {
            try {
                Trip item = _context.Trips
                            .Include(x=>x.Stops)
                            .Where(y => y.TripID.Equals(tripID)).FirstOrDefault();

                List<Stop> stops = _context.Stops
                            .Where(s => s.TripID.Equals(item.TripID))
                            .ToList();
                foreach(Stop stop in stops)
                {
                    _context.Stops
                        .Remove(stop);
                }
                _context.Trips
                        .Remove(item);
            _context.SaveChangesAsync();
                return 1;
            }
            catch(Exception ex)
            {
                return -1;
            }
        }

        private int GetTripIDByTripName(Trip newTrip)
        {
            return _context.Trips
                .Where(x => x.Name.Equals(newTrip.Name))
                .Select(x => x.TripID)
                .FirstOrDefault();   
        }

        private int GetTripIDByTripName(string newTrip)
        {
            return _context.Trips
                .Where(x => x.Name.Equals(newTrip))
                .Select(x => x.TripID)
                .FirstOrDefault();
        }



        public int DeleteTrip(string newTrip)
        {
            var tripID = GetTripIDByTripName(newTrip);
            int status = DeleteStopForTripID(tripID);
            return status;
        }

        public int DeleteStop(string[] items)
        {
            var tripID = GetTripIDByTripName(items[0]);
            int status = DeleteStopForTripID(tripID, items[1]);
            return status;
        }

        private int DeleteStopForTripID(int tripID, string name)
        {
            try
            {
                Stop stops = _context.Stops
                            .Where(s => s.TripID.Equals(tripID) && s.Name.Equals(name))
                            .FirstOrDefault();
                
                _context.Stops
                        .Remove(stops);
                _context.SaveChangesAsync();
                return 1;
            }
            catch (Exception ex)
            {
                return -1;
            }
        }
    }
}
