﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace CoreProject1.Models
{
    public interface IWorldRepository
    {
        IEnumerable<Trip> GetAllTrips();
        IEnumerable<Trip> GetAllTripsByUserName(string name);
        void AddTrip(Trip trip);
        int DeleteTrip(string newTrip);
        Trip GetTripByName(string tripName);
        Trip GetUserTripByName(string tripName, string name);
        Task<bool> SaveChangesAsync();
        void AddStop(string tripName, Stop newStop);
        void AddStop(string tripName, Stop newStop, string name);
        int DeleteStop(string[] items);
    }
}