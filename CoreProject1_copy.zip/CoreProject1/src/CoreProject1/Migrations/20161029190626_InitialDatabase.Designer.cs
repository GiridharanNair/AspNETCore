﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;
using CoreProject1.Models;

namespace CoreProject1.Migrations
{
    [DbContext(typeof(WorldContext))]
    [Migration("20161029190626_InitialDatabase")]
    partial class InitialDatabase
    {
        protected override void BuildTargetModel(ModelBuilder modelBuilder)
        {
            modelBuilder
                .HasAnnotation("ProductVersion", "1.0.1")
                .HasAnnotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn);

            modelBuilder.Entity("CoreProject1.Models.Stop", b =>
                {
                    b.Property<int>("StopID")
                        .ValueGeneratedOnAdd();

                    b.Property<DateTime>("ArrivalDate");

                    b.Property<double>("Latitude");

                    b.Property<double>("Longitude");

                    b.Property<string>("Name");

                    b.Property<int>("Order");

                    b.Property<int?>("TripID");

                    b.HasKey("StopID");

                    b.HasIndex("TripID");

                    b.ToTable("Stops");
                });

            modelBuilder.Entity("CoreProject1.Models.Trip", b =>
                {
                    b.Property<int>("TripID")
                        .ValueGeneratedOnAdd();

                    b.Property<DateTime>("DateCreated");

                    b.Property<string>("Name");

                    b.Property<string>("UserName");

                    b.HasKey("TripID");

                    b.ToTable("Trips");
                });

            modelBuilder.Entity("CoreProject1.Models.Stop", b =>
                {
                    b.HasOne("CoreProject1.Models.Trip")
                        .WithMany("Stops")
                        .HasForeignKey("TripID");
                });
        }
    }
}
