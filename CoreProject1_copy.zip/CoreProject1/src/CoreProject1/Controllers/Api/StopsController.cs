﻿using AutoMapper;
using CoreProject1.Models;
using CoreProject1.Services;
using CoreProject1.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoreProject1.Controllers.Api
{
    [Authorize]
    [Route("/api/trips/{tripName}/stops")]
    public class StopsController:Controller
    {
        private GeoCordsService _geoServiceObj;
        private ILogger<StopsController> _logger;
        private IWorldRepository _repository;

        public StopsController(IWorldRepository repository, ILogger<StopsController> logger, GeoCordsService geoServiceObj)
        {
            _repository = repository;
            _logger = logger;
            _geoServiceObj = geoServiceObj;
        }

        [HttpGet("")]
        public IActionResult Get(string tripName)
        {
            try { 
            var trip = _repository.GetUserTripByName(tripName,this.User.Identity.Name);
            return Ok(
                Mapper.Map<IEnumerable<StopViewModel>>(trip.Stops
                .OrderBy(s=>s.Order).ToList())
                );
            }
            catch(Exception ex)
            {
                _logger.LogError("Could not fetch the Stops for the trip",ex);
            }
            return BadRequest("Failed to get Stops");
        }

        [HttpPost("")]
        public async Task<IActionResult> Post(string tripName,[FromBody]StopViewModel svmObject)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var newStop = Mapper.Map<Stop>(svmObject);
                    //newStop.Name = this.User.Identity.Name;
                    //Lookup the Latitude and Longitude from the Bing Map API

                    var result = await _geoServiceObj.GetCoordsAsync(newStop.Name);
                    if (!result.Success)
                    {
                        _logger.LogError("Failed to get co-ordinates");
                    }
                    else {
                        newStop.Latitude = result.Latitude;
                        newStop.Longitude = result.Longitude; 
                    _repository.AddStop(tripName,newStop,User.Identity.Name);
                    if(await _repository.SaveChangesAsync()) { 
                    return Created($"/api/trips/{tripName}/stops/{newStop.Name}",
                        Mapper.Map<StopViewModel>(newStop)
                        );
                    }
                    }
                }
                else
                    return BadRequest("Failed to add stop to the database");


            }
            catch(Exception ex)
            {
                _logger.LogInformation("Failed to get post stop Data");
                return BadRequest("Failed to add stop to the database");
            }
            return BadRequest("Failed to add stop to the database");
        }



        [HttpDelete("")]
        public IActionResult Delete(string tripName)
        {
            try
            {
                string[] items = tripName.Split('|');
                if (_repository.DeleteStop(items) > 0) {
                    _repository.SaveChangesAsync();
                var trip = _repository.GetUserTripByName(items[0], this.User.Identity.Name);
                return Ok(
                    Mapper.Map<IEnumerable<StopViewModel>>(trip.Stops
                    .OrderBy(s => s.Order).ToList())
                    );
                }
            }
            catch (Exception ex)
            {
                _logger.LogInformation("Failed to get post stop Data");
                return BadRequest("Failed to add stop to the database");
            }
            return BadRequest("Failed to add stop to the database");
        }

    }
}
