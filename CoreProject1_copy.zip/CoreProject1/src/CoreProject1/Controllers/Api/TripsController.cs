﻿using AutoMapper;
using CoreProject1.Models;
using CoreProject1.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoreProject1.Controllers.Api
{
    [Route("api/trips")]
    [Authorize]
    public class TripsController:Controller
    {
        private ILogger<TripsController> _logger;
        private IWorldRepository _repository;

        public TripsController(IWorldRepository repository,ILogger<TripsController> logger)
        {
            _repository = repository;
            _logger = logger;
        }
        [HttpGet("")]
        public IActionResult Get()
        {
            try { 
            var results = _repository.GetAllTripsByUserName(this.User.Identity.Name);
            return Ok(Mapper.Map<IEnumerable<TripViewModel>>(results));
            }
            catch(Exception ex)
            {
                // To Do Logging
                _logger.LogError("Loading Data failed",ex);
               return BadRequest("Loading Data failed");
            }
        }

        [HttpPost("")]
        public async Task<IActionResult> Post([FromBody]TripViewModel trpObject)
        {
            if (ModelState.IsValid) {
                //save to the database
                var newTrip = Mapper.Map<Trip>(trpObject);

                newTrip.UserName = User.Identity.Name;
                _repository.AddTrip(newTrip);

                    if(await _repository.SaveChangesAsync()) { 
                        return Created($"api/trips/{newTrip.Name}", Mapper.Map<TripViewModel>(newTrip));
                    }
                    else
                    {
                    return BadRequest("Failed to save changes to the Database");
                    }
            }

            return BadRequest(ModelState);
        }
        [HttpDelete("/api/trips/{tripName}")]
        public IActionResult Delete(string tripName)
        {
            try {
                //Trip newTrip = _repository.GetTripByName(tripName);
                if (_repository.DeleteTrip(tripName) > 0) { 
                try
                {
                    _repository.SaveChangesAsync();
                    var results = _repository.GetAllTripsByUserName(this.User.Identity.Name);
                    return Ok(Mapper.Map<IEnumerable<TripViewModel>>(results));
                        //return Created($"api/trips/{tripName}", Mapper.Map<TripViewModel>(newTrip));
                       // return NoContent();
                }
                catch (Exception ex)
                {
                    // To Do Logging
                    _logger.LogError("Loading Data failed", ex);
                    return BadRequest("Loading Data failed");
                }
                }
                return BadRequest("Loading Data failed");
            }
            catch(Exception ex)
            {
                return BadRequest(ModelState);
            }

        }

    }
}
