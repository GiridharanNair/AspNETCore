﻿using CoreProject1.Models;
using CoreProject1.ViewModels;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoreProject1.Controllers
{
    public class AuthController:Controller
    {
        private IConfigurationRoot _config;
        private SignInManager<TripUser> _signInManager;

        public AuthController(SignInManager<TripUser> signInManager, IConfigurationRoot config)
        {
            _signInManager = signInManager;
            _config = config;
        }
        public IActionResult Login()
        {
            if (User.Identity.IsAuthenticated)
            {
                return RedirectToAction("Trips", "App");
            }

            return View();
        }

        [HttpPost]
        public async Task<ActionResult> Login(LoginViewModel lvm, string returnURL)
        {
            if (ModelState.IsValid)
            {
                var signInResult = await _signInManager.PasswordSignInAsync(lvm.UserName,
                                                                     lvm.Password,
                                                                     true,false);
                if (signInResult.Succeeded)
                {
                    if (String.IsNullOrWhiteSpace(returnURL))
                        return RedirectToAction("Trips", "App");
                    else
                        return Redirect(returnURL);
                }
                else
                {
                    ModelState.AddModelError("", "UserName or Password is incorrect");
                }
            }
            
            return View();
        }
        

        public async Task<ActionResult> Logout()
        {
            if (User.Identity.IsAuthenticated)
            {
                await _signInManager.SignOutAsync();
            }
            return RedirectToAction("Index", "App");
        }


        public async Task<ActionResult> SignInWithFaceBook()
        {
            if (User.Identity.IsAuthenticated)
            {
                await _signInManager.SignOutAsync();
                return Redirect("https://www.facebook.com/login.php?skip_api_login=1&api_key=" + _config["FaceBook:AppId"] + "&api_secret=" + _config["FaceBook:AppSecret"]);
            }
            
            return RedirectToAction("Index", "App");
        }
    }
}
